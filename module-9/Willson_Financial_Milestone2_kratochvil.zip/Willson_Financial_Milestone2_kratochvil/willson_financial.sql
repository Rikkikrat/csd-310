DROP DATABASE IF EXISTS willson_financial;
CREATE DATABASE willson_financial;
USE willson_financial;

CREATE TABLE Client (
    client_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    client_type VARCHAR(50),
    phone VARCHAR(20),
    email VARCHAR(100),
    date_added DATE
);

CREATE TABLE Advisor (
    advisor_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    certification VARCHAR(50),
    phone VARCHAR(20),
    email VARCHAR(100)
);

CREATE TABLE Employee (
    employee_id INT PRIMARY KEY AUTO_INCREMENT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    role VARCHAR(50),
    phone VARCHAR(20),
    email VARCHAR(100)
);

CREATE TABLE Account (
    account_id INT PRIMARY KEY AUTO_INCREMENT,
    client_id INT,
    advisor_id INT,
    account_type VARCHAR(50),
    balance DECIMAL(12,2),
    open_date DATE,
    FOREIGN KEY (client_id) REFERENCES Client(client_id),
    FOREIGN KEY (advisor_id) REFERENCES Advisor(advisor_id)
);

CREATE TABLE Asset_Holding (
    holding_id INT PRIMARY KEY AUTO_INCREMENT,
    account_id INT,
    asset_type VARCHAR(50),
    quantity DECIMAL(10,2),
    market_value DECIMAL(12,2),
    valuation_date DATE,
    FOREIGN KEY (account_id) REFERENCES Account(account_id)
);

CREATE TABLE Transaction_Record (
    transaction_id INT PRIMARY KEY AUTO_INCREMENT,
    account_id INT,
    transaction_date DATE,
    transaction_type VARCHAR(50),
    amount DECIMAL(12,2),
    description VARCHAR(255),
    FOREIGN KEY (account_id) REFERENCES Account(account_id)
);

CREATE TABLE Appointment (
    appointment_id INT PRIMARY KEY AUTO_INCREMENT,
    client_id INT,
    employee_id INT,
    advisor_id INT,
    appointment_date DATETIME,
    purpose VARCHAR(255),
    FOREIGN KEY (client_id) REFERENCES Client(client_id),
    FOREIGN KEY (employee_id) REFERENCES Employee(employee_id),
    FOREIGN KEY (advisor_id) REFERENCES Advisor(advisor_id)
);

CREATE TABLE Billing_Plan (
    billing_plan_id INT PRIMARY KEY AUTO_INCREMENT,
    plan_name VARCHAR(50),
    fee_percentage DECIMAL(5,2),
    description VARCHAR(255)
);

CREATE TABLE Invoice (
    invoice_id INT PRIMARY KEY AUTO_INCREMENT,
    client_id INT,
    billing_plan_id INT,
    invoice_date DATE,
    total_amount DECIMAL(12,2),
    FOREIGN KEY (client_id) REFERENCES Client(client_id),
    FOREIGN KEY (billing_plan_id) REFERENCES Billing_Plan(billing_plan_id)
);

CREATE TABLE Invoice_Line (
    invoice_line_id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_id INT,
    service_description VARCHAR(255),
    line_amount DECIMAL(12,2),
    FOREIGN KEY (invoice_id) REFERENCES Invoice(invoice_id)
);

CREATE TABLE Compliance_Review (
    review_id INT PRIMARY KEY AUTO_INCREMENT,
    employee_id INT,
    review_date DATE,
    findings VARCHAR(255),
    status VARCHAR(50),
    FOREIGN KEY (employee_id) REFERENCES Employee(employee_id)
);

INSERT INTO Client (first_name, last_name, client_type, phone, email, date_added)
VALUES
('John', 'Smith', 'Retiree', '555-1111', 'john@email.com', '2026-01-10'),
('Mary', 'Jones', 'Farmer', '555-2222', 'mary@email.com', '2026-01-15'),
('Robert', 'Brown', 'Rancher', '555-3333', 'robert@email.com', '2026-02-01'),
('Lisa', 'White', 'Individual', '555-4444', 'lisa@email.com', '2026-02-05'),
('David', 'Green', 'Retiree', '555-5555', 'david@email.com', '2026-03-01'),
('Sarah', 'Black', 'Farmer', '555-6666', 'sarah@email.com', '2026-03-10');

INSERT INTO Advisor (first_name, last_name, certification, phone, email)
VALUES
('Jake', 'Willson', 'CFA', '555-7001', 'jake@wf.com'),
('Ned', 'Willson', 'CFA', '555-7002', 'ned@wf.com'),
('Amy', 'Clark', 'CPA', '555-7003', 'amy@wf.com'),
('Ryan', 'Hall', 'CFA', '555-7004', 'ryan@wf.com'),
('Emily', 'Stone', 'CPA', '555-7005', 'emily@wf.com'),
('Chris', 'Lee', 'CFA', '555-7006', 'chris@wf.com');

INSERT INTO Employee (first_name, last_name, role, phone, email)
VALUES
('Phoenix', 'Two Star', 'Office Assistant', '555-8001', 'phoenix@wf.com'),
('June', 'Santos', 'Compliance Manager', '555-8002', 'june@wf.com'),
('Kelly', 'Moore', 'Receptionist', '555-8003', 'kelly@wf.com'),
('Mark', 'Davis', 'Assistant', '555-8004', 'mark@wf.com'),
('Tina', 'Evans', 'Coordinator', '555-8005', 'tina@wf.com'),
('Brian', 'Hill', 'Scheduler', '555-8006', 'brian@wf.com');

INSERT INTO Billing_Plan (plan_name, fee_percentage, description)
VALUES
('Standard', 1.25, 'Standard investment fee'),
('Premium', 1.75, 'Premium advising service'),
('Basic', 0.90, 'Basic service plan'),
('Retirement', 1.10, 'Retirement planning'),
('Agriculture', 1.40, 'Farm and ranch planning'),
('Executive', 2.00, 'Executive financial planning');

INSERT INTO Account (client_id, advisor_id, account_type, balance, open_date)
VALUES
(1,1,'Retirement',50000,'2026-01-10'),
(2,2,'Investment',75000,'2026-01-15'),
(3,1,'Savings',25000,'2026-02-01'),
(4,3,'Investment',100000,'2026-02-05'),
(5,4,'Retirement',80000,'2026-03-01'),
(6,5,'Savings',30000,'2026-03-10');

INSERT INTO Asset_Holding (account_id, asset_type, quantity, market_value, valuation_date)
VALUES
(1,'Stocks',100,15000,'2026-05-01'),
(2,'Bonds',200,22000,'2026-05-01'),
(3,'Mutual Fund',75,12000,'2026-05-01'),
(4,'ETF',50,18000,'2026-05-01'),
(5,'Stocks',150,30000,'2026-05-01'),
(6,'Cash',1,30000,'2026-05-01');

INSERT INTO Transaction_Record (account_id, transaction_date, transaction_type, amount, description)
VALUES
(1,'2026-05-01','Deposit',5000,'Monthly deposit'),
(2,'2026-05-02','Withdrawal',2000,'Emergency expense'),
(3,'2026-05-03','Trade',3000,'Stock purchase'),
(4,'2026-05-04','Deposit',10000,'Bonus contribution'),
(5,'2026-05-05','Trade',4000,'ETF purchase'),
(6,'2026-05-06','Withdrawal',1500,'Bill payment');

INSERT INTO Appointment (client_id, employee_id, advisor_id, appointment_date, purpose)
VALUES
(1,1,1,'2026-05-10 09:00:00','Retirement review'),
(2,1,2,'2026-05-10 10:00:00','Investment consultation'),
(3,3,1,'2026-05-11 11:00:00','Account setup'),
(4,4,3,'2026-05-11 01:00:00','Portfolio review'),
(5,5,4,'2026-05-12 02:00:00','Financial planning'),
(6,6,5,'2026-05-12 03:00:00','Savings consultation');

INSERT INTO Invoice (client_id, billing_plan_id, invoice_date, total_amount)
VALUES
(1,1,'2026-05-01',625.00),
(2,2,'2026-05-01',1312.50),
(3,3,'2026-05-01',225.00),
(4,4,'2026-05-01',1100.00),
(5,5,'2026-05-01',1120.00),
(6,6,'2026-05-01',600.00);

INSERT INTO Invoice_Line (invoice_id, service_description, line_amount)
VALUES
(1,'Portfolio management',625.00),
(2,'Premium advisory service',1312.50),
(3,'Basic account maintenance',225.00),
(4,'Retirement planning service',1100.00),
(5,'Agricultural investment service',1120.00),
(6,'Executive financial review',600.00);

INSERT INTO Compliance_Review (employee_id, review_date, findings, status)
VALUES
(2,'2026-05-01','No issues found','Completed'),
(2,'2026-05-02','Minor documentation issue','Completed'),
(2,'2026-05-03','Policy updated','Completed'),
(2,'2026-05-04','Review pending signatures','Pending'),
(2,'2026-05-05','Client file verified','Completed'),
(2,'2026-05-06','Transaction review completed','Completed');
________________________________________
