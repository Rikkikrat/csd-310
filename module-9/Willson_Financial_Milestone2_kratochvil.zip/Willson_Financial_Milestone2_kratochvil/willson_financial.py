import mysql.connector

# Database connection
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Dragon@1",
    database="willson_financial"
)

cursor = mydb.cursor()

# Function to display table data

def show_table(table_name):
    print(f"\nDISPLAYING {table_name.upper()} TABLE")
    print("-" * 50)

    cursor.execute(f"SELECT * FROM {table_name}")
    rows = cursor.fetchall()

    for row in rows:
        print(row)

# Display all tables
show_table("Client")
show_table("Advisor")
show_table("Employee")
show_table("Account")
show_table("Asset_Holding")
show_table("Transaction_Record")
show_table("Appointment")
show_table("Billing_Plan")
show_table("Invoice")
show_table("Invoice_Line")
show_table("Compliance_Review")

cursor.close()
mydb.close()
